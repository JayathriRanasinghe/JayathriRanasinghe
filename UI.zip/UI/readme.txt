main.html - the main page with the backgroud image 

index.html - the homepage

pages:

donor login 
donor registration pages

seeker search page

